package lidyaevtrans;

import java.io.IOException;


public class Lidyaevtrans {

    public static void main(String[] args) throws IOException {
        new NewJFrame().setVisible(true);

    }
}
