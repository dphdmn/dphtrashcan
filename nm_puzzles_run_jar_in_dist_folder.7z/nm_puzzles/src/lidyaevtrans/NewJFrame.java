/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lidyaevtrans;

import java.awt.Desktop;
import java.awt.List;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author dml
 */
public class NewJFrame extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public NewJFrame() {
        initComponents();
        
        jTextArea1.getDocument().addDocumentListener(new DocumentListener() {

            @Override
            public void insertUpdate(DocumentEvent de) {
                runMagic();
            }

            @Override
            public void removeUpdate(DocumentEvent de) {
                runMagic();
            }

            @Override
            public void changedUpdate(DocumentEvent de) {
                runMagic();
            }
    });
        
    }
    /*
        Основная функция программы, вызываемая при каждом вводе в форму слева
    */
    private void runMagic()
    {
        //Обнуление формы и запрос текста
        jTextArea2.setText("");
        String mytext = jTextArea1.getText();
        //Добавление текста на форму, требует STRING
        jTextArea2.append(makeMatrix(mytext));

    }
    
    private String makeMatrix(String inText)
    {
        String outText = "";
        String[] array = inText.split("\n");
        ArrayList intList = new ArrayList();
        Collections.addAll(intList, array);
        boolean[] empty1 = new boolean[1000];
        boolean[] empty2 = new boolean[1000];
        for(int i = 0; i<=999;i++)
        {
            empty1[i]=true;
            empty2[i]=true;
        }
        String[][] mat = new String[1000][1000];
        for (int j = 0; j<intList.size();j++){
            Object i = intList.get(j);
            String is = i.toString();
            int ind = is.indexOf(" ");
            String s = "";
            int n1 = 0;
            int n2 = 0;
            String nextString="";
            String user = "";
            String time = "";
            if (ind == -1){
                s = "ERROR";
            }
            else{
                s = is.substring(0, ind);
                n1 = Integer.parseInt(s.substring(0, s.indexOf("x")));
                n2 = Integer.parseInt(s.substring(s.indexOf("x")+1));
                user = is.substring(is.indexOf(" ")+2); // errors
                nextString=user;
                user = user.substring(0,user.indexOf(" ")); 
                time = nextString.substring(nextString.indexOf(" ")+2); // errors
                time = time.substring(0, time.indexOf(" "));
                mat[n1-1][n2-1]=user + " [" + time + "]";
                empty1[n1-1]=false;
                empty2[n2-1]=false;
            }
            
        }
        outText += "N/M \t";
        for (int i = 2; i<=1000;i++){
            if (!empty2[i-1])
            outText += i + "\t";
        }
        outText += "\n";
        for (int i = 1; i<1000;i++)
        {
            if(!empty1[i]){
                outText += (i+1)+"\t";
                for (int j=1;j<1000;j++)
                {
                    if (!empty2[j]){
                    if (mat[i][j] == null){
                        mat[i][j] = "-";
                    }
                    outText +=mat[i][j] + "\t";
                    }
                }
                outText += "\n";
            }
        }
        
        return outText;
    }
    
    /*
        Функция для обработки вводимого текста
    */
    private String handleMacro(String inText)
    {
        String outText = "";
        /*
        String[] array = inText.split(" ");
        ArrayList intList = new ArrayList();
        Collections.addAll(intList, array);
	Collections.shuffle(intList);
	for (Object i:intList){
            outText+=i + " ";
        }
        */
        String mKey = "MACRO";
        String eKey = "ENDM";
        /*Первый проход - поиск макроопределений, занесение имен, и тел в списки*/
        ArrayList bodyM = new ArrayList();
        ArrayList nameM = new ArrayList();
        ArrayList parM = new ArrayList();
        
        String[] array = inText.split("\n");
        ArrayList intList = new ArrayList();
        Collections.addAll(intList, array);
        boolean macrostarted = false;
        boolean macroadded = false;
        for (int j = 0; j<intList.size();j++){
            Object i = intList.get(j);
            String is = i.toString();
            if (is.contains(" " + mKey))
            {
                macrostarted = true;
            }
            if (is.contains(eKey)){
                intList.remove(i); j--;
                macrostarted = false;
                macroadded = false;
            }
            if (macrostarted){
                if (!macroadded){
                    if (is.indexOf(mKey) == 0){ 
                        outText += "Ошибка, не задано имя макроса.";
                        break;
                    }
                    
                    Object macroname = is.substring(0, is.indexOf(mKey)-1).replaceAll(" ", "");
                    if (nameM.contains(macroname)){
                            outText += "Ошибка, дублирование имени макроопределения";
                            break;
                        }
                    else{
                        int lastInd = is.indexOf(mKey)+mKey.length()+1;
                        String parString;
                        if (lastInd < is.length()-1){              
                            parString = is.substring(lastInd,is.length()).replaceAll(" ", "").replaceAll(" ,", ",").replaceAll(",,", ",");
                        }
                        else {
                            parString = "";
                        }
                        ArrayList p = new ArrayList();
                        Collections.addAll(p, parString.split(",")); 
                        parM.add(p);
                        nameM.add(macroname);
                        bodyM.add("");
                        macroadded = true;
                    }
                }
                else{
                    int lastIndex = bodyM.size()-1;
                    Object el = bodyM.get(lastIndex);
                    Object newEl = el.toString()+i.toString()+"\n";
                    bodyM.set(lastIndex, newEl);
                }
                intList.remove(i); j--;
            }
        }
        if (macrostarted){
            outText += "Ошибка. Не закончен макрос."; 
        }
        
        /*Второй проход - замена всех вызовов телами макроопределений*/
         for (int j = 0; j<intList.size();j++){
            Object i = intList.get(j);
            String is = i.toString();
            boolean isMacro = false;
            for(Object n:nameM){
                if (is.contains(n.toString())){
                    int id = nameM.indexOf(n);
                    String body = bodyM.get(id).toString();
                    ArrayList mypar=(ArrayList)parM.get(id);
                    if(mypar.size() > 0){
                        //проверяем параметры, если они требуются
                        String ourstring = is.substring(is.indexOf(n.toString())+n.toString().length(),is.length()).replaceAll(" ", "").replaceAll(" ,", ",").replaceAll(",,", ",");
                        ArrayList p = new ArrayList();
                        Collections.addAll(p, ourstring.split(",")); 
                        if (mypar.size() != p.size()){
                            outText += "Ошибка, неверное число параметров в макроопределении " + n + "\n____\n";
                            break;
                        }
                        else{
                            for(Object par:mypar){
                                String parS = par.toString();
                                body = body.replaceAll(parS, p.get(mypar.indexOf(par)).toString());
                            }
                        }
                    }
                    outText += body;
                    isMacro = true;
                    break;
                }
            }
            if (!isMacro){
                outText += i + "\n";
            } 
         }
        
        return outText;        
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jMenu2.setText("File");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jMenu2MousePressed(evt);
            }
        });

        jMenuItem1.setText("open");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem1);

        jMenuItem2.setText("save");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem2);

        jMenuItem3.setText("run");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem3);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 562, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 553, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MousePressed
       // 
    }//GEN-LAST:event_jMenu2MousePressed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
    
    JFileChooser chooser = new JFileChooser();
    File myfile = null;
    
    FileNameExtensionFilter filter = new FileNameExtensionFilter("txt","txt");
    chooser.setFileFilter(filter);
    int returnVal = chooser.showOpenDialog(jMenu2);
    if(returnVal == JFileChooser.APPROVE_OPTION) 
    {
        myfile = chooser.getSelectedFile();
    }
     
        FileReader reader = null;
        try {
            reader = new FileReader(myfile);
        } catch (FileNotFoundException ex) {
            System.out.println("Файл не найден.");
        }
        String text = new String();
        int i;
        try {
            while ((i = reader.read()) != -1) {
                text += (char) i;
            }
            
        } catch (IOException e) {
            System.out.println("Ошибка чтения файла.");
            
        }

        try {
            reader.close();
            System.out.println("Файл успешно прочитан.");
        } catch (IOException e) {
            System.out.println("Ошибка закрытия файла.");
        }
        
        jTextArea1.setText(text);
        
        
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
       try(FileWriter writer = new FileWriter("C://Users/dml/Desktop/masmpr/m.asm", false))
        {
           // запись всей строки
            String text = jTextArea2.getText();
            writer.write(text); 
            writer.flush();
            
            
        }
        catch(IOException ex){
             
            System.out.println(ex.getMessage());
        } 
        try {
            Runtime.getRuntime().exec("cmd /c C://Users/dml/Desktop/masmpr/cr.bat");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());}
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
       File file=new File("C://Users/dml/Desktop/masmpr/m.exe");
        try {
            Desktop.getDesktop().open(file);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_jMenuItem3ActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables
}
